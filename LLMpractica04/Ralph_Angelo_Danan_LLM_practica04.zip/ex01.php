<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="generalista.php">
            <h1 style="font-size: 30px; background-color:silver; ">Tria un numero</h1>
       <input type="number" min="5" max="30" name="numero" />
       <input type="submit"/>
       </form>
    </body>
</html>

<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
           <h1>Introduzca la realización de cada tortuga.</h1>
         <form action="calculos.php" formtarget="result" autocomplete="on" method="POST">
             Leonardo:<input required type="number" name="leo" min="0" max="10">
             Raphael:<input required type="number" name="rap" min="0" max="10">
             Donatello:<input required type="number" name="don" min="0" max="10">
             Michelangelo:<input required type="number" name="mic" min="0" max="10"><br/><br/>
             <input type="submit" value="Registrar"/>
      
    </body>
</html>

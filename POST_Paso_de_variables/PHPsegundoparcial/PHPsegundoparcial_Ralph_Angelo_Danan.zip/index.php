<html>
    <head>
        <meta charset="UTF-8">
        <title>Catering</title>
    </head>
    <body>
        <h1>Catering</h1>
        <br/>
            <a href="altapreplatos.php">Alta Preparación Platos</a>
        <br/>
        <br/>
            <a href="modprecioplato.php">Modificar Precio Plato</a>
        <br/>
        <br/>
        <a href="listadoclientes.php">Listado Clientes</a>
        <br/>
        <br/>
            <a href="borrarcliente.php">Borrar Cliente</a>
        <br/>
  
        <?php
        // put your code here
        ?>
    </body>
</html>
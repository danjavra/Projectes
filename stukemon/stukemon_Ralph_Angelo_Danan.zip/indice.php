
<html>
    <head>
        <meta charset="UTF-8">
        <title>Stukemon</title>
    </head>
    <body>
        <h1>Stukemon Go!</h1>
        <br/>
            <a href="altaentrenador.php">Nuevo Entrenador</a>
        <br/>
        <br/>
            <a href="altapokemon.php">Nuevo Pokemon</a>
        <br/>
        <br/>
        <a href="batallaentrenadores.php">Batalla</a>
        <br/>
        <br/>
            <a href="mejorarvida.php">Mejorar Vida</a>
        <br/>
        <br/>
            <a href="pocionessalud.php">Conseguir pociones de salud</a>
        <br/>
        <br/>
            <a href="listadopokemons.php">Listado Pokemon</a>
        <br/>
        <br/>
            <a href="rankingentrenadores.php">Ranking Entrenadores</a>
        <br/>
        <br/>
            <a href="rankingbatallas.php">Ranking Batallas</a>
        <br/>
        <br/>
     
        
        <?php
        // put your code here
        ?>
    </body>
</html>